
import { VirtualCard, Transaction } from '../types';

const EXCHANGE_RATE = 120.50; // 1 USD = 120.50 BDT

export const fintechService = {
  convertBDTtoUSD: (amount: number): number => {
    return Number((amount / EXCHANGE_RATE).toFixed(2));
  },

  convertUSDtoBDT: (amount: number): number => {
    return Number((amount * EXCHANGE_RATE).toFixed(2));
  },

  mockTransactions: (): Transaction[] => [
    { id: '1', title: 'Facebook Ads', amount: 25.00, currency: 'USD', type: 'DEBIT', date: '2023-10-25', category: 'Marketing' },
    { id: '2', title: 'bKash Deposit', amount: 5000, currency: 'BDT', type: 'CREDIT', date: '2023-10-24', category: 'Wallet' },
    { id: '3', title: 'YouTube Premium', amount: 11.99, currency: 'USD', type: 'DEBIT', date: '2023-10-22', category: 'Subscription' },
    { id: '4', title: 'DigitalOcean', amount: 6.00, currency: 'USD', type: 'DEBIT', date: '2023-10-20', category: 'Server' },
    { id: '5', title: 'Nagad Deposit', amount: 2000, currency: 'BDT', type: 'CREDIT', date: '2023-10-18', category: 'Wallet' },
  ],

  generateMockCard: (name: string): VirtualCard => {
    return {
      id: Math.random().toString(36).substr(2, 9),
      cardNumber: Array.from({ length: 4 }, () => Math.floor(1000 + Math.random() * 9000)).join(' '),
      expiry: '12/28',
      cvv: Math.floor(100 + Math.random() * 900).toString(),
      brand: 'VISA',
      balance: 10.00,
      status: 'ACTIVE',
      cardholder: name.toUpperCase()
    };
  }
};
