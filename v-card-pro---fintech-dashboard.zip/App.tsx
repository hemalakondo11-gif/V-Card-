
import React, { useState, useEffect, useCallback } from 'react';
import { GoogleGenAI } from "@google/genai";
import { VirtualCard, Transaction, WalletBalance, View } from './types';
import { fintechService } from './services/fintechService';
import CardWidget from './components/CardWidget';
import TransactionList from './components/TransactionList';

const App: React.FC = () => {
  // State
  const [view, setView] = useState<View>(View.DASHBOARD);
  const [cards, setCards] = useState<VirtualCard[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [wallet, setWallet] = useState<WalletBalance>({ bdt: 15000, usd: 45.20 });
  const [loading, setLoading] = useState(false);
  const [depositAmount, setDepositAmount] = useState<string>('');
  
  // AI Insights State
  const [insights, setInsights] = useState<string>("");

  useEffect(() => {
    // Initial data load
    setTransactions(fintechService.mockTransactions());
    const initialCard = fintechService.generateMockCard("Fahim Morshed");
    setCards([initialCard]);
  }, []);

  const handleIssueCard = () => {
    if (wallet.usd < 10) {
      alert("Insufficient USD balance to issue a card. Minimum $10 required.");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      const newCard = fintechService.generateMockCard("Fahim Morshed");
      setCards([...cards, newCard]);
      setWallet(prev => ({ ...prev, usd: prev.usd - 10 }));
      setTransactions(prev => [{
        id: Math.random().toString(),
        title: 'New Virtual Card Fee',
        amount: 10,
        currency: 'USD',
        type: 'DEBIT',
        date: new Date().toISOString().split('T')[0],
        category: 'Cards'
      }, ...prev]);
      setLoading(false);
      setView(View.CARDS);
    }, 1500);
  };

  const handleDeposit = () => {
    const amt = parseFloat(depositAmount);
    if (!amt || amt <= 0) return;

    setLoading(true);
    // Simulate SSLCommerz / bKash Gateway
    setTimeout(() => {
      setWallet(prev => ({ ...prev, bdt: prev.bdt + amt }));
      setTransactions(prev => [{
        id: Math.random().toString(),
        title: 'bKash Add Money',
        amount: amt,
        currency: 'BDT',
        type: 'CREDIT',
        date: new Date().toISOString().split('T')[0],
        category: 'Wallet'
      }, ...prev]);
      setDepositAmount('');
      setLoading(false);
      setView(View.DASHBOARD);
    }, 2000);
  };

  const handleConversion = () => {
    if (wallet.bdt < 1200) return; // Min conversion 10 USD approx
    const bdtToDeduct = 6000; // Fixed amount for demo
    const usdToAdd = fintechService.convertBDTtoUSD(bdtToDeduct);
    
    setWallet(prev => ({
      bdt: prev.bdt - bdtToDeduct,
      usd: prev.usd + usdToAdd
    }));

    setTransactions(prev => [{
      id: Math.random().toString(),
      title: 'Currency Swap (BDT to USD)',
      amount: bdtToDeduct,
      currency: 'BDT',
      type: 'DEBIT',
      date: new Date().toISOString().split('T')[0],
      category: 'Exchange'
    }, ...prev]);
  };

  const generateInsights = async () => {
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analyze these fintech transactions and provide a short 2-sentence spending insight for the user: ${JSON.stringify(transactions.slice(0, 5))}`,
      });
      setInsights(response.text || "You are spending efficiently on marketing services.");
    } catch (error) {
      setInsights("Unable to fetch AI insights at this time.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#0f172a] text-slate-200">
      {/* Sidebar - Desktop */}
      <aside className="w-full md:w-64 glass border-b md:border-b-0 md:border-r border-white/10 p-6 flex flex-col justify-between">
        <div>
          <div className="flex items-center space-x-3 mb-10">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <i className="fas fa-bolt text-white text-xl"></i>
            </div>
            <h1 className="text-xl font-bold tracking-tight text-white">V-Card <span className="text-indigo-400">Pro</span></h1>
          </div>
          
          <nav className="space-y-2">
            {[
              { id: View.DASHBOARD, icon: 'fa-chart-pie', label: 'Dashboard' },
              { id: View.CARDS, icon: 'fa-credit-card', label: 'My Cards' },
              { id: View.TRANSACTIONS, icon: 'fa-list-ul', label: 'History' },
              { id: View.DEPOSIT, icon: 'fa-plus-circle', label: 'Add Money' },
            ].map(item => (
              <button
                key={item.id}
                onClick={() => setView(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${view === item.id ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'}`}
              >
                <i className={`fas ${item.icon}`}></i>
                <span className="font-medium">{item.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="mt-10 p-4 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border border-white/5">
          <p className="text-xs text-slate-500 mb-1">Exchange Rate</p>
          <p className="text-sm font-semibold text-emerald-400">1 USD = 120.50 BDT</p>
          <button onClick={handleConversion} className="mt-3 w-full py-2 text-xs font-bold bg-white/5 hover:bg-white/10 rounded-lg transition-colors border border-white/10">
            QUICK SWAP ৳6000
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto">
        <header className="flex flex-col md:flex-row md:items-center justify-between mb-10 space-y-4 md:space-y-0">
          <div>
            <h2 className="text-2xl font-bold text-white">Welcome back, Fahim</h2>
            <p className="text-slate-400">Manage your virtual spending and local wallet.</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
               <p className="text-xs text-slate-500 uppercase font-bold tracking-tighter">Wallet Status</p>
               <p className="text-indigo-400 font-mono">VERIFIED USER</p>
            </div>
            <div className="w-12 h-12 rounded-full border-2 border-indigo-500 p-0.5">
               <img src="https://picsum.photos/200" className="w-full h-full rounded-full object-cover" alt="Profile" />
            </div>
          </div>
        </header>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: Balances & Cards */}
          <div className="lg:col-span-2 space-y-8">
            
            <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
               <div className="p-6 rounded-2xl glass relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-4 text-emerald-500/20 group-hover:scale-110 transition-transform">
                    <i className="fas fa-wallet text-6xl"></i>
                  </div>
                  <p className="text-slate-400 text-sm font-medium">BDT Balance</p>
                  <p className="text-3xl font-bold text-white mt-1">৳{wallet.bdt.toLocaleString()}</p>
                  <button onClick={() => setView(View.DEPOSIT)} className="mt-4 text-xs font-bold text-indigo-400 hover:text-indigo-300 flex items-center">
                    ADD FUNDS <i className="fas fa-arrow-right ml-2 text-[10px]"></i>
                  </button>
               </div>
               <div className="p-6 rounded-2xl glass relative overflow-hidden group border-indigo-500/20">
                  <div className="absolute top-0 right-0 p-4 text-indigo-500/20 group-hover:scale-110 transition-transform">
                    <i className="fas fa-dollar-sign text-6xl"></i>
                  </div>
                  <p className="text-slate-400 text-sm font-medium">USD Wallet</p>
                  <p className="text-3xl font-bold text-white mt-1">${wallet.usd.toLocaleString()}</p>
                  <button onClick={handleIssueCard} className="mt-4 text-xs font-bold text-indigo-400 hover:text-indigo-300 flex items-center">
                    ISSUE NEW CARD <i className="fas fa-plus ml-2 text-[10px]"></i>
                  </button>
               </div>
            </section>

            {view === View.DASHBOARD && (
              <section className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-white">Your Primary Card</h3>
                  <button onClick={() => setView(View.CARDS)} className="text-xs text-indigo-400 hover:underline">View All</button>
                </div>
                {cards.length > 0 ? (
                  <CardWidget card={cards[0]} />
                ) : (
                  <div className="h-56 rounded-2xl border-2 border-dashed border-white/10 flex items-center justify-center">
                    <button onClick={handleIssueCard} className="text-slate-500 hover:text-slate-300 transition-colors">
                      <i className="fas fa-plus-circle text-3xl mb-2"></i>
                      <p className="text-sm font-medium">Generate Your First Card</p>
                    </button>
                  </div>
                )}
              </section>
            )}

            {view === View.CARDS && (
              <section className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-white">Active Virtual Cards</h3>
                  <button 
                    disabled={loading}
                    onClick={handleIssueCard} 
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold shadow-lg shadow-indigo-600/20 flex items-center"
                  >
                    {loading ? <i className="fas fa-spinner fa-spin mr-2"></i> : <i className="fas fa-plus mr-2"></i>}
                    New Card ($10)
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {cards.map(c => <CardWidget key={c.id} card={c} />)}
                </div>
              </section>
            )}

            {view === View.DEPOSIT && (
               <section className="max-w-md mx-auto space-y-6 glass p-8 rounded-3xl">
                  <div className="text-center">
                    <h3 className="text-xl font-bold text-white mb-2">Add Money</h3>
                    <p className="text-sm text-slate-400">Top up your BDT wallet via SSLCommerz Gateway</p>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <label className="text-xs font-bold text-slate-500 uppercase block mb-1">Select Amount (BDT)</label>
                      <input 
                        type="number"
                        value={depositAmount}
                        onChange={(e) => setDepositAmount(e.target.value)}
                        placeholder="e.g. 5000"
                        className="w-full bg-slate-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500 transition-colors"
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                       {['1000', '5000', '10000'].map(v => (
                         <button key={v} onClick={() => setDepositAmount(v)} className="py-2 rounded-lg bg-white/5 text-xs hover:bg-white/10 border border-white/5">৳{v}</button>
                       ))}
                    </div>
                    <button 
                      onClick={handleDeposit}
                      disabled={loading || !depositAmount}
                      className="w-full py-4 bg-[#e2136e] hover:bg-[#c4105f] text-white rounded-xl font-bold shadow-lg flex items-center justify-center transition-transform active:scale-95"
                    >
                      {loading ? <i className="fas fa-spinner fa-spin mr-2"></i> : <i className="fas fa-lock mr-2"></i>}
                      Pay with bKash / Nagad
                    </button>
                  </div>
               </section>
            )}

            {view === View.TRANSACTIONS && (
               <TransactionList transactions={transactions} />
            )}
          </div>

          {/* Right Column: Insights & Quick Actions */}
          <div className="space-y-8">
             <div className="p-6 rounded-2xl bg-indigo-600 shadow-xl shadow-indigo-600/20 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                  <i className="fas fa-magic text-6xl"></i>
                </div>
                <h4 className="text-white font-bold mb-2">AI Financial Assistant</h4>
                <p className="text-indigo-100 text-sm leading-relaxed mb-4">
                  {insights || "Get personalized spending analysis based on your recent transactions."}
                </p>
                <button 
                  onClick={generateInsights}
                  disabled={loading}
                  className="w-full py-2 bg-white text-indigo-600 rounded-xl text-xs font-bold hover:bg-indigo-50 transition-colors flex items-center justify-center"
                >
                  {loading ? <i className="fas fa-spinner fa-spin mr-2"></i> : <i className="fas fa-sparkles mr-2"></i>}
                  GENERATE INSIGHTS
                </button>
             </div>

             <div className="p-6 rounded-2xl glass border border-white/5">
                <h4 className="text-white font-bold mb-4">Service Status</h4>
                <div className="space-y-4">
                  {[
                    { label: 'Virtual Issuing', status: 'Online', color: 'text-emerald-400' },
                    { label: 'SSLCommerz', status: 'Operational', color: 'text-emerald-400' },
                    { label: 'Card Funding', status: 'Slow', color: 'text-orange-400' },
                  ].map(s => (
                    <div key={s.label} className="flex items-center justify-between text-xs">
                      <span className="text-slate-400">{s.label}</span>
                      <span className={`font-bold ${s.color}`}>{s.status}</span>
                    </div>
                  ))}
                </div>
             </div>

             <div className="p-6 rounded-2xl glass border border-white/5 space-y-4">
                <h4 className="text-white font-bold">Supported Platforms</h4>
                <div className="grid grid-cols-4 gap-4 text-slate-500 text-2xl">
                  <i className="fab fa-facebook hover:text-blue-500 transition-colors"></i>
                  <i className="fab fa-google hover:text-red-400 transition-colors"></i>
                  <i className="fab fa-aws hover:text-orange-400 transition-colors"></i>
                  <i className="fab fa-digital-ocean hover:text-blue-400 transition-colors"></i>
                </div>
                <p className="text-[10px] text-slate-500 italic">Cards are 3D Secure (3DS) ready for worldwide merchant support.</p>
             </div>
          </div>
        </div>
      </main>

      {/* Mobile Navigation Sticky */}
      <div className="md:hidden sticky bottom-0 left-0 right-0 glass border-t border-white/10 flex justify-around p-4 z-50">
        {[
          { id: View.DASHBOARD, icon: 'fa-home' },
          { id: View.CARDS, icon: 'fa-credit-card' },
          { id: View.DEPOSIT, icon: 'fa-plus' },
          { id: View.TRANSACTIONS, icon: 'fa-history' },
        ].map(item => (
          <button
            key={item.id}
            onClick={() => setView(item.id)}
            className={`text-xl ${view === item.id ? 'text-indigo-500' : 'text-slate-500'}`}
          >
            <i className={`fas ${item.icon}`}></i>
          </button>
        ))}
      </div>
    </div>
  );
};

export default App;
