
import React, { useState } from 'react';
import { VirtualCard } from '../types';

interface CardWidgetProps {
  card: VirtualCard;
}

const CardWidget: React.FC<CardWidgetProps> = ({ card }) => {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <div className="relative w-full max-w-md h-56 rounded-2xl p-6 flex flex-col justify-between overflow-hidden shadow-2xl transition-all hover:scale-[1.02] cursor-pointer card-gradient group">
      {/* Decorative patterns */}
      <div className="absolute -right-10 -top-10 w-40 h-40 bg-white opacity-10 rounded-full blur-2xl"></div>
      <div className="absolute -left-10 -bottom-10 w-32 h-32 bg-indigo-900 opacity-20 rounded-full blur-2xl"></div>

      <div className="flex justify-between items-start z-10">
        <div>
          <p className="text-xs font-medium text-white/70 uppercase tracking-widest">Virtual Card</p>
          <p className="text-xl font-bold text-white mt-1">{card.brand}</p>
        </div>
        <div className="flex space-x-1">
          <div className="w-8 h-8 rounded-full bg-orange-500 opacity-80"></div>
          <div className="w-8 h-8 rounded-full bg-red-500 opacity-80 -ml-4"></div>
        </div>
      </div>

      <div className="z-10">
        <div className="flex items-center space-x-4">
           <p className="text-2xl font-mono tracking-[0.2em] text-white">
            {showDetails ? card.cardNumber : card.cardNumber.replace(/\d{4} \d{4} \d{4}/, '•••• •••• ••••')}
          </p>
          <button 
            onClick={() => setShowDetails(!showDetails)}
            className="text-white/60 hover:text-white transition-colors"
          >
            <i className={`fas fa-eye${showDetails ? '-slash' : ''}`}></i>
          </button>
        </div>
      </div>

      <div className="flex justify-between items-end z-10">
        <div>
          <p className="text-[10px] text-white/60 uppercase">Card Holder</p>
          <p className="text-sm font-semibold text-white tracking-wider">{card.cardholder}</p>
        </div>
        <div className="flex space-x-6">
          <div>
            <p className="text-[10px] text-white/60 uppercase">Expires</p>
            <p className="text-sm font-semibold text-white">{card.expiry}</p>
          </div>
          <div>
            <p className="text-[10px] text-white/60 uppercase">CVV</p>
            <p className="text-sm font-semibold text-white">
              {showDetails ? card.cvv : '•••'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardWidget;
