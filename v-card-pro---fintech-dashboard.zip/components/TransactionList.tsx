
import React from 'react';
import { Transaction } from '../types';

interface TransactionListProps {
  transactions: Transaction[];
}

const TransactionList: React.FC<TransactionListProps> = ({ transactions }) => {
  const getIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'marketing': return 'fa-bullhorn';
      case 'wallet': return 'fa-wallet';
      case 'subscription': return 'fa-rotate';
      case 'server': return 'fa-server';
      default: return 'fa-receipt';
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-slate-200 px-1">Recent Activity</h3>
      <div className="space-y-2">
        {transactions.map((tx) => (
          <div key={tx.id} className="flex items-center justify-between p-4 rounded-xl glass hover:bg-white/10 transition-colors group">
            <div className="flex items-center space-x-4">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${tx.type === 'CREDIT' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-700/50 text-slate-400'}`}>
                <i className={`fas ${getIcon(tx.category)}`}></i>
              </div>
              <div>
                <p className="font-medium text-slate-100">{tx.title}</p>
                <p className="text-xs text-slate-500">{tx.date} • {tx.category}</p>
              </div>
            </div>
            <div className="text-right">
              <p className={`font-semibold ${tx.type === 'CREDIT' ? 'text-emerald-400' : 'text-slate-100'}`}>
                {tx.type === 'CREDIT' ? '+' : '-'}{tx.currency === 'USD' ? '$' : '৳'}{tx.amount.toLocaleString()}
              </p>
              <p className="text-[10px] text-slate-500 uppercase tracking-tighter">{tx.type}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TransactionList;
