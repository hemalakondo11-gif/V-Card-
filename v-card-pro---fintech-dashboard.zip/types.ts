
export interface Transaction {
  id: string;
  title: string;
  amount: number;
  currency: 'BDT' | 'USD';
  type: 'DEBIT' | 'CREDIT';
  date: string;
  category: string;
}

export interface VirtualCard {
  id: string;
  cardNumber: string;
  expiry: string;
  cvv: string;
  brand: 'VISA' | 'MASTERCARD';
  balance: number;
  status: 'ACTIVE' | 'FROZEN';
  cardholder: string;
}

export interface WalletBalance {
  bdt: number;
  usd: number;
}

export enum View {
  DASHBOARD = 'DASHBOARD',
  CARDS = 'CARDS',
  TRANSACTIONS = 'TRANSACTIONS',
  DEPOSIT = 'DEPOSIT'
}
